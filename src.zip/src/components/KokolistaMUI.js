import React from 'react';
import {Line as LineChart} from 'react-chartjs';
import "../css/tyyli.css";

function chartData() {
  return {
    labels: ['Vastasyntynyt', '3 kk', '6 kk', '9 kk', '1 v', '1 v 6 kk', '2 v', '3 v', '4 v', '5 v', '6 v', '7 v'],
    datasets: [
      {
        label: 'Keskimääräinen pituus',
        fillColor: 'rgba(220,220,220,0.2)',
        strokeColor: 'rgba(220,220,220,1)',
        pointColor: 'rgba(220,220,220,1)',
        pointStrokeColor: '#fff',
        pointHighlightFill: '#fff',
        pointHighlightStroke: 'rgba(220,220,220,1)',
        data: [52, 63, 70, 75, 78, 84, 88, 97, 105, 111, 118, 125 ],
      },
      {
        label: 'Oma pituus',
        fillColor: 'rgba(151,187,205,0.2)',
        strokeColor: 'rgba(151,187,205,1)',
        pointColor: 'rgba(151,187,205,1)',
        pointStrokeColor: '#fff',
        pointHighlightFill: '#fff',
        pointHighlightStroke: 'rgba(151,187,205,1)',
        data: [53, 65, 71, 74, 79, 85, 89, 98, 105],
      },
    ]
  }
}


class LineChartExample extends React.Component {

  constructor(props) {
    super(props)
    this.state = {
      data: chartData()
    }
  }

  render() {
    return (
      <div>
        <LineChart data={this.state.data}
          width="600" height="250"/>
      </div>
    )
  }
}

export default LineChartExample;