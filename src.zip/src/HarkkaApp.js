import React, { Component } from "react";
import MenuMUI from "./navigation/MenuMUI";
import {BrowserRouter, Route, Switch} from "react-router-dom";
import KokolistaMUI from "./components/KokolistaMUI";
import KokolomakeMUI from "./components/KokolomakeMUI";
import SanontalomakeMUI from "./components/SanontalomakeMUI";
import SanontalistaMUI from "./components/SanontalistaMUI";

const san = [
    {
        ika: "4 vuotta",
        paivamaara: "21.2.2019",
        tilanne: "Menossa nukkumaan",
        sanonta: "Syökö siat sieniä? Kärpäset syö ainakin kärpässieniä."
    },
    {
        ika: "4 vuotta",
        paivamaara: "27.1.2019",
        tilanne: "Kantoi siskoa sylissä",
        sanonta: "Nyt sisko on kyllä muuttunut aika painavaksi, kun se on 2-vuotias. Nyt se on kokonainen."
    }
];

class HarkkaApp extends Component {
    render() {
        return (
            <BrowserRouter>
                <div>
                {
                    
                }
                    <MenuMUI/>
                    <Switch>
                        <Route exact path="/" render= {(props) => <SanontalistaMUI{...props} sanonnat={san}/>} />
                        <Route exact path="/etusivu"    render= {(props) => <SanontalistaMUI{...props} sanonnat={san}/>} />
                        <Route path="/lisaasanonta"             component={SanontalomakeMUI} />
                        <Route path="/listaasanonnat" render= {(props) => <SanontalistaMUI{...props} sanonnat={san}/>} />
                        <Route path="/lisaakoko" component=     {KokolomakeMUI} />
                        <Route path="/kokotaulukko" components={KokolistaMUI} />
                    </Switch>
                </div>
            </BrowserRouter>
        );
    }
}
export default HarkkaApp;